@echo off

rem %0 is this batch file
rem %1 is the CLI exe name, which must be in the same dir as this
rem %2 is the version number
rem %3 is the path to open (optional, default to user's home path)

set exeName=%1

set dfVersion=%2

if "%~3"=="" (
	set startDrive=%HOMEDRIVE%
	set startPath=%HOMEPATH%
) ELSE (
	set startDrive=%~d3
	set startPath=%~pnx3
)

title Dotfuscator Command Prompt %dfVersion%
echo %startDrive%%startPath%^>%exeName% /?
cmd /k "set PATH=%~dp0;%PATH% & %startDrive% & cd %startPath% & %exeName% /?"